#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <locale.h>
#include "pim.h"

#define CLEAN_BUFF                                  \
    do                                              \
    {                                               \
        int c;                                      \
        while ((c = getchar()) != '\n' && c != EOF) \
            ;                                       \
    } while (0) // substitui esse parte por getchar() se voce preferir

#define MAX_SENHA 8
#define MAX_LOGIN 50

//**Cadastro de usuarios

int cad_user()
{   setlocale(LC_ALL, "Portuguese");
    int ncad = 0, nlaco = 0, ncfm = 0;
    char *user = (char *)malloc(sizeof *user * MAX_LOGIN);
    char *senha, *confirmaSenha;

    do  
    {
        system("cls");
        puts("\n**WIKLATECH**\n\n");
        puts("*-> Cadastro de usu�rio:\n");

        do
        {
            fflush(stdin);
            FILE *fileuser;
            if (ncad == 1)
            {
                printf("\nUsuario j� existe, digite outro usu�rio: ");
            }
            else
            {
                printf("\nDigite novo usu�rio: ");
            }

            gets(user);
            fflush(stdin);
            fileuser = fopen("usuarios.txt", "a+");
            ncad = checkuser(fileuser, user); // se retorna 1 o login ja existe
            fclose(fileuser);

        } while (ncad == 1);

        do
        {
            printf("\nSenha de at� 8 digitos: ");
            senha = CriaSenha();
            fflush(stdin);
            printf("\nConfirmacao de senha: ");
            confirmaSenha = CriaSenha();
            printf("\n");
            fflush(stdin);
            if (!strcmp(senha, confirmaSenha))
                break;
            else
                system("cls");
            printf("\nAs senhas n�o s�o iguais. Tente novamente.\n");
            system("pause");

        } while (1);

        do
        {
            system("cls");
            puts("\n**WIKLATECH**\n\n");
            puts("*-> Cadastro de usu�rio:\n");
            printf("\n Confirme o Cadastro:\n1- Confirmar e voltar para o menu.\n2- Refazer cadastro.\n ");
            scanf("%d", &ncfm);

            if (ncfm == 1)
            {
                nlaco = 0;
            }
            else if (ncfm == 2)
            {
                nlaco = 0;
                puts("\n"); 
				system("pause");               
            }
            else
            {
                puts("\nDigite 1 ou 2...");
                system("pause");
                nlaco = 1;
            }

            system("cls");

        } while (nlaco == 1);

        if (ncfm == 2)
        {
            nlaco = 1;
        }

    } while (nlaco == 1);

    FILE *fileuser;
    fileuser = fopen("usuarios.txt", "a+");
    fprintf(fileuser, "%s %s \n", user, senha);
    fclose(fileuser);
    system("cls");
    free(senha);
    free(confirmaSenha);
    puts("\n**WIKLATECH**\n\n");
    puts("\nUsu�rio confirmado...\n");
    

    return 1;
}

