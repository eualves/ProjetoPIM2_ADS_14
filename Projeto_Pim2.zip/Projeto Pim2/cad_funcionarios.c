#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <locale.h>
#include "pim.h"

#define CLEAN_BUFF                                  \
    do                                              \
    {                                               \
        int c;                                      \
        while ((c = getchar()) != '\n' && c != EOF) \
            ;                                       \
    } while (0) // substitui esse parte por getchar() se voce preferir

#define MAX_SENHA 8
#define MAX_LOGIN 50

//**Cadastro de Funcionarios
int cad_func()
{   setlocale(LC_ALL, "Portuguese");
    char func[5][100];
    int n_nomef, nfcpf, nendcf, ncidadef, ntelf, nfimf, lacof = 0;
    int i;

    do
    {
        system("cls");
        puts("\n**WIKLATECH**\n\n");
        if (lacof == 1)
        {
            puts("\n**Cadastro de Funcion�rios**\n\n");
        }

        do
        { //--------*0- Nome *----------------------------------------------------------------------------------------

            if (lacof == 0)
            {
                puts("\n**Cadastro de Funcion�rios**\n\n");
            }

            puts("\nDigite o nome o completo do Funcion�rio:\n ");

            fgets(func[0], 70, stdin);
            fflush(stdin);

            puts("\nNome digitado:\n");
            puts(func[0]);

            do
            {
                puts("\nConfirme se o nome est� correto:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");
                scanf("%d", &n_nomef);
                fflush(stdin);
                if (n_nomef == 1)
                {
                    lacof = 0;
                    puts("\nNome confirmado...");
                    system("pause");
                }
                else if (n_nomef == 2)
                {
                    lacof = 0;
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    lacof = 1;
                }

                system("cls");

            } while (lacof == 1);

            if (n_nomef == 2)
            {
                lacof = 1;
            }

        } while (lacof == 1);

        do
        { //--------*1- CPF *----------------------------------------------------------------------------------------

            puts("\n**Cadastro de Funcion�rios**\n\n");
            puts("\nDigite o CPF:\n ");

            fgets(func[1], 70, stdin);
            fflush(stdin);

            puts("\nCPF digitado:\n");
            puts(func[1]);

            do
            {
                puts("\nConfirme se o CPF est� correto:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");

                scanf("%d", &nfcpf);
                fflush(stdin);

                if (nfcpf == 1)
                {
                    lacof = 0;
                    puts("\nCPF confirmado.\n");
                    system("pause");
                }
                else if (nfcpf == 2)
                {
                    lacof = 0;
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    lacof = 1;
                }

                system("cls");

            } while (lacof == 1);

            if (nfcpf == 2)
            {
                lacof = 1;
            }

        } while (lacof == 1);

        do
        { //-------*2-Endere�o *----------------------------------------------------------------------------------

            puts("\n**Cadastro de Funcion�rios**\n\n");

            puts("\nDigite o endere�o:\n");

            fgets(func[2], 70, stdin);
            fflush(stdin);

            puts("\nEndere�o digitado:\n");
            puts(func[2]);

            do
            {

                puts("\nConfirme se o endere�o est� correto:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");
                scanf("%d", &nendcf);
                fflush(stdin);
                if (nendcf == 1)
                {
                    lacof = 0;
                    puts("\nEndere�o confirmado.\n");
                    system("pause");
                }
                else if (nendcf == 2)
                {
                    lacof = 0;
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    lacof = 1;
                }

                system("cls");

            } while (lacof == 1);

            if (nendcf == 2)
            {
                lacof = 1;
            }

        } while (lacof == 1);

        do
        { //-------*3- Cidade *----------------------------------------------------------------------------------

            puts("\n**Cadastro de Funcion�rios**\n\n");

            puts("\nDigite o nome da cidade:\n");

            fgets(func[3], 70, stdin);
            fflush(stdin);

            puts("\nCidade digitada:\n");
            puts(func[3]);

            do
            {

                puts("\nConfirme se a cidade est� correta:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");
                scanf("%d", &ncidadef);
                fflush(stdin);

                if (ncidadef == 1)
                {
                    lacof = 0;
                    puts("\nCidade confirmada.\n");
                    system("pause");
                }
                else if (ncidadef == 2)
                {
                    lacof = 0;
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    lacof = 1;
                }

                system("cls");

            } while (lacof == 1);

            if (ncidadef == 2)
            {
                lacof = 1;
            }

        } while (lacof == 1);

        do
        { //-------*4- Telefone *----------------------------------------------------------------------------------

            puts("\n**Cadastro de Funcion�rios**\n\n");

            puts("\nDigite o n�mero do telefone:\n");

            fgets(func[4], 70, stdin);
            fflush(stdin);

            puts("\nTelefone digitado:\n");
            puts(func[4]);

            do
            {
                puts("\nConfirme se o telefone est� correto:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");
                scanf("%d", &ntelf);
                fflush(stdin);

                if (ntelf == 1)
                {
                    lacof = 0;
                    puts("\nTelefone confirmado.\n");
                    system("pause");
                }
                else if (ntelf == 2)
                {
                    lacof = 0;
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    lacof = 1;
                }

                system("cls");

            } while (lacof == 1);

            if (ntelf == 2)
            {
                lacof = 1;
            }

        } while (lacof == 1);

        //-------* Cadastro completo *------------------------------------------------------------------------------------
        do
        {
            puts("\nCadastro completo:\n\n");

            for (i = 0; i < 5; i++)
            {
                puts(func[i]);
            }

            puts("\nConfirme se o cadastro est� correto:\n1- Confirmar e finalizar cadastro.\n2- Cadastrar novamente.\n");
            scanf("%d", &nfimf);
            fflush(stdin);

            if (nfimf == 1)
            {
                lacof = 0;
                puts("\nCadastro confirmado.\n");
                system("pause");
            }
            else if (nfimf == 2)
            {
                lacof = 0;
                puts("\n");
            }
            else
            {
                puts("\nDigite 1 ou 2...");
                system("pause");
                lacof = 1;
            }

            system("cls");

        } while (lacof == 1);

        if (nfimf == 2)
        {
            lacof = 1;
        }

    } while (lacof == 1);

    FILE *filefunc;

    filefunc = fopen("funcionarios.txt", "a+");

    for (i = 0; i < 5; i++)
    {
        fprintf(filefunc, func[i]);
    }
    fclose(filefunc);
    return 0;
}
