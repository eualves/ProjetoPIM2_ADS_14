#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <locale.h>
#include "pim.h"

#define CLEAN_BUFF                                  \
    do                                              \
    {                                               \
        int c;                                      \
        while ((c = getchar()) != '\n' && c != EOF) \
            ;                                       \
    } while (0) // substitui esse parte por getchar() se voce preferir

#define MAX_SENHA 8
#define MAX_LOGIN 50


int cad_cliente() //Cadastro de clientes
{
    setlocale(LC_ALL, "Portuguese");
    char cliente[6][100], cliente2[6][100];

    int npessoa = 0, np, nfim, laco = 0;
    int nc_nome, cpf_cnpj, nendc, ncidade, ntel, i;
    FILE *fcliente;
    do
    {
        system("cls");
        puts("\n**WIKLATECH**\n\n");

        puts("\n**Cadastro de Clientes**\n\n");

        do
        { //--------*Inicio *0- Pessoa *----------------------------------------------------------------------------------------

            do
            {
                puts("PESSOA:\n1- Jur�dica\n2- F�sica\n ");
                scanf("%d", &npessoa);
                fflush(stdin);

                if (npessoa == 1)
                {
                    laco = 0;
                    strcpy(cliente[0], "Pessoa Jur�dica\n");
                    puts("\n");
                }
                else if (npessoa == 2)
                {
                    laco = 0;
                    strcpy(cliente[0], "Pessoa F�sica\n");
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    laco = 1;
                }
            } while (laco == 1);

            puts("Op��o: ");
            puts(cliente[0]);

            do
            {
                puts("\nConfirmar op��o selecionada:\n1- Confirmar e continuar cadastro.\n2- Selecionar novamente.\n");
                scanf("%d", &np);
                fflush(stdin);

                if (np == 1)
                {
                    puts("\nOp��o confirmada...");
                    system("pause");
                }
                else if (np == 2)
                {
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    laco = 1;
                }

                system("cls");

            } while (laco == 1);

            if (np == 2)
            {
                laco = 1;
            }

        } while (laco == 1);

        do
        { //--------*1- Nome *----------------------------------------------------------------------------------------
            puts("\n**Cadastro de Clientes**\n\n");

            if (npessoa == 1)
            {
                puts("\nDigite o nome da empresa:\n");
            }
            else
            {
                puts("\nDigite o nome completo do cliente:\n ");
            }

            fgets(cliente[1], 70, stdin);
            fflush(stdin);

            puts("\nNome digitado:\n");
            puts(cliente[1]);

            do
            {
                puts("\nConfirme se o nome est� correto:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");
                scanf("%d", &nc_nome);
                fflush(stdin);
                if (nc_nome == 1)
                {
                    laco = 0;
                    puts("\nNome confirmado...");
                    system("pause");
                }
                else if (nc_nome == 2)
                {
                    laco = 0;
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    laco = 1;
                }

                system("cls");

            } while (laco == 1);

            if (nc_nome == 2)
            {
                laco = 1;
            }

        } while (laco == 1);

        do
        { //--------*2- CPF - CNPJ *----------------------------------------------------------------------------------------
            puts("\n**Cadastro de Clientes**\n\n");

            if (npessoa == 1)
            {

                puts("\nDigite o CNPJ sem barra:\n");
            }
            else
            {
                puts("\nDigite o CPF:\n ");
            }

            fgets(cliente[2], 70, stdin);
            fflush(stdin);

            puts("\nNumero digitado:\n");
            puts(cliente[2]);

            do
            {
                if (npessoa == 1)
                {
                    puts("\nConfirme se o CNPJ est� correto:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");
                }
                else
                {
                    puts("\nConfirme se o CPF est� correto:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");
                }

                scanf("%d", &cpf_cnpj);
                fflush(stdin);

                if (cpf_cnpj == 1)
                {
                    laco = 0;
                    if (npessoa == 1)
                    {
                        puts("\nCNPJ confirmado.\n");
                    }
                    else
                    {
                        puts("\nCPF confirmado.\n");
                    }
                    system("pause");
                }
                else if (cpf_cnpj == 2)
                {
                    laco = 0;
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    laco = 1;
                }

                system("cls");

            } while (laco == 1);

            if (cpf_cnpj == 2)
            {
                laco = 1;
            }

        } while (laco == 1);

        do
        { //-------*3-Endereco *----------------------------------------------------------------------------------
            puts("\n**Cadastro de Clientes**\n\n");

            puts("\nDigite o endere�o:\n");

            fgets(cliente[3], 70, stdin);
            fflush(stdin);

            puts("\nEndere�o digitado:\n");
            puts(cliente[3]);

            do
            {

                puts("\nConfirme se o endere�o correto:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");
                scanf("%d", &nendc);
                fflush(stdin);
                if (nendc == 1)
                {
                    laco = 0;
                    puts("\nEndere�o confirmado.\n");
                    system("pause");
                }
                else if (nendc == 2)
                {
                    laco = 0;
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    laco = 1;
                }

                system("cls");

            } while (laco == 1);

            if (nendc == 2)
            {
                laco = 1;
            }

        } while (laco == 1);

        do
        { //-------*4- Cidade *----------------------------------------------------------------------------------
            puts("\n**Cadastro de Clientes**\n\n");

            puts("\nDigite o nome da cidade:\n");

            fgets(cliente[4], 70, stdin);
            fflush(stdin);

            puts("\nCidade digitada:\n");
            puts(cliente[4]);

            do
            {

                puts("\nConfirme se a cidade est� correta:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");
                scanf("%d", &ncidade);
                fflush(stdin);

                if (ncidade == 1)
                {
                    laco = 0;
                    puts("\nCidade confirmada.\n");
                    system("pause");
                }
                else if (ncidade == 2)
                {
                    laco = 0;
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    laco = 1;
                }

                system("cls");

            } while (laco == 1);

            if (ncidade == 2)
            {
                laco = 1;
            }

        } while (laco == 1);

        do
        { //-------*5- Telefone *----------------------------------------------------------------------------------
            puts("\n**Cadastro de Clientes**\n\n");

            puts("\nDigite o numero do telefone:\n");

            fgets(cliente[5], 70, stdin);
            fflush(stdin);

            puts("\nTelefone digitado:\n");
            puts(cliente[5]);
            strcat(cliente[5], "\n");
            do
            {
                puts("\nConfirme se o telefone est� correto:\n1- Confirmar e continuar cadastro.\n2- Digitar novamente.\n");
                scanf("%d", &ntel);
                fflush(stdin);

                if (ntel == 1)
                {
                    laco = 0;
                    puts("\nTelefone confirmado.\n");
                    system("pause");
                }
                else if (ntel == 2)
                {
                    laco = 0;
                    puts("\n");
                }
                else
                {
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                    laco = 1;
                }

                system("cls");

            } while (laco == 1);

            if (ntel == 2)
            {
                laco = 1;
            }

        } while (laco == 1);

        //-------* Cadastro completo *------------------------------------------------------------------------------------
        do
        {
            puts("\nCadastro completo:\n\n");

            for (i = 0; i < 6; i++)
            {
                puts(cliente[i]);
            }

            puts("\nConfirme se o cadastro est� correto:\n1- Confirmar e finalizar cadastro.\n2- Cadastrar novamente.\n");
            scanf("%d", &nfim);
            fflush(stdin);

            if (nfim == 1)
            {
                laco = 0;
                puts("\nCadastro confirmado.\n");
                system("pause");
            }
            else if (nfim == 2)
            {
                laco = 0;
                puts("\n");
            }
            else
            {
                puts("\nDigite 1 ou 2...");
                system("pause");
                laco = 1;
            }

        } while (laco == 1);

        if (nfim == 2)
        {
            laco = 1;
        }
    //**Salva cadastro ---------------------------------------------------------------
    } while (laco == 1);
    if (npessoa == 1)
    {
        fcliente = fopen("clientes-pessoa-juridica.txt", "a+");
    }
    else
    {
        fcliente = fopen("clientes-pessoa-fisica.txt", "a+");
    }

    for (i = 0; i < 6; i++)
    {
        fprintf(fcliente, cliente[i]);
    }
    fclose(fcliente);
    return 0;
}

