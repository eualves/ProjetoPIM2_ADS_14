
int relatorios();

int cad_func();

int cad_cliente();

int cad_user();
