#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <locale.h>
#include "pim.h"

#define CLEAN_BUFF                                  \
    do                                              \
    {                                               \
        int c;                                      \
        while ((c = getchar()) != '\n' && c != EOF) \
            ;                                       \
    } while (0) // substitui esse parte por getchar() se voce preferir

#define MAX_SENHA 8
#define MAX_LOGIN 50

//**MENU DE RELATORIOS

int relatorios()
{   setlocale(LC_ALL, "Portuguese");
    int nrel = 0, npessoa = 0, i, n, nstart=0;
    char str1[100], str2[100], sfgets2[100];
    do
    { //--------- Relatorios *------------------------------------------------------------------------//
        system("cls");
        puts("\n**WIKLATECH**\n\n");
        puts("\n**Relat�rios**\n\n");
        puts("\n1- Relat�rio de usuarios\n2- Relat�rio de funcionarios\n3- Relat�rio de clientes\n");
        puts("4- Sair\n");
        scanf("%d", &nrel);
        fflush(stdin);

        switch (nrel)
        {
        case 1: // RELATORIO DE USUARIO
            system("cls");
            puts("\n**WIKLATECH**\n\n");
            printf("\nUsu�rios cadastrados: \n");
            FILE *fuser;
            fuser = fopen("usuarios.txt", "a+");

            while (fgets(sfgets2, 100, fuser) != NULL)
            {
                printf("%s", sfgets2);
            }
            fclose(fuser);
            system("pause");
            break;

        case 2: // RELATORIO DE FUNCIONARIOS
            do
            {   i = 0;
			    nstart=0;
                system("cls");
                puts("\n**WIKLATECH**\n\n");
                fflush(stdin);
                printf("Digite o nome do Funcion�rio: ");
                fgets(str2, 100, stdin);
                fflush(stdin);

                FILE *frelf;

                frelf = fopen("funcionarios.txt", "a+");
                while (fgets(str1, 100, frelf) != NULL)
                {
                    if (!strcmp(str2, str1))
                    {
                        nstart = 1;
                    }
                    if (nstart == 1)
                    {
                        if (i == 5)
                        {
                            break;
                        }
                        printf("\n%s", str1);
                        i++;
                    }
                }

                fclose(frelf);
                if (nstart == 0)
                {
                    printf("\nFuncion�rio n�o encontrado...\n");
                }
                printf("\n\nDeseja digitar novamente?\n1- Sim\n2- Nao\n\n");
                scanf("%d", &n);
                fflush(stdin);
                if (n == 1)
                {
                    i = 0;
                    nstart = 0;
                    system("pause");
                }
                else if (n == 2)
                {
                    puts("\n");
                    break;
                }
                else
                {
                    i = 0;
                    nstart = 0;
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                }

            } while (1);
            break;

        case 3: // RELATORIOS DE CLIENTES
            do
            {   i = 0;
			    nstart=0;
                FILE *fcli;
                npessoa = 0;
                system("cls");
                puts("\n**WIKLATECH**\n\n");
                puts("\nPESSOA:\n1- Jur�dica\n2- F�sica\n\n");
                scanf("%d", &npessoa);
                fflush(stdin);

                if (npessoa == 1)
                {
                    system("cls");
                    puts("\n**WIKLATECH**\n\n");
                    fflush(stdin);
                    fcli = fopen("clientes-pessoa-juridica.txt", "a+");
                    printf("Digite o nome da empresa: ");
                }
                else if (npessoa == 2)
                {
                    system("cls");
                    puts("\n**WIKLATECH**\n\n");
                    fflush(stdin);
                    fcli = fopen("clientes-pessoa-fisica.txt", "a+");
                    printf("Digite o nome do Cliente: ");
                }
                fflush(stdin);
                fgets(str2, 100, stdin);
                fflush(stdin);

                while (fgets(str1, 100, fcli) != NULL)
                {
                    if (!strcmp(str2, str1))
                    {
                        nstart = 1;
                    }
                    if (nstart == 1)
                    {
                        if (i == 5)
                        {
                            break;
                        }
                        printf("\n%s", str1);
                        i++;
                    }
                }

                fclose(fcli);
                if (nstart == 0)
                {
                    printf("\nNome n�o encontrado...\n");
                }
                printf("\n\nDeseja digitar novamente?\n1- Sim\n2- Nao\n\n");
                scanf("%d", &n);
                fflush(stdin);
                if (n == 1)
                {
                    i = 0;
                    nstart = 0;
                    system("pause");
                }
                else if (n == 2)
                {
                    puts("\n");
                    break;
                }
                else
                {
                    i = 0;
                    nstart = 0;
                    puts("\nDigite 1 ou 2...");
                    system("pause");
                }

            } while (1);

            puts("\n");
            break;

        case 4:
            system("pause");
            return 0;
            break;

        default:
            puts("\nDigite 1, 2, 3 ou 4...");
            system("pause");
        }

    } while (1);

    return 0;
}
