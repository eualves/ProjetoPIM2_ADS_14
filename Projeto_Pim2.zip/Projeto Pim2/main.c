#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <locale.h>
#include "pim.h"

#define CLEAN_BUFF                                  \
    do                                              \
    {                                               \
        int c;                                      \
        while ((c = getchar()) != '\n' && c != EOF) \
            ;                                       \
    } while (0) // substitui esse parte por getchar() se voce preferir

#define MAX_SENHA 8
#define MAX_LOGIN 50


int checklogin(FILE *file, char *user, char *senha) // Verifica se o um usuario login e valido
{
    char tmpLogin[MAX_LOGIN];
    char tmpSenha[MAX_SENHA];

    fscanf(file, "%s", tmpLogin);

    while (!feof(file))
    {
        if (!strcmp(tmpLogin, user))
        {
            fscanf(file, "%s", tmpSenha);

            if (!strcmp(tmpSenha, senha))
                return 1;
        }
        else
        {
            fscanf(file, "%*s");
        }
        fscanf(file, "%s", tmpLogin);
    }

    return 0;
}

int checkuser(FILE *file, char *user) // Verifica se um usuario valido
{
    char tmpLogin[MAX_LOGIN];
    char tmpSenha[MAX_SENHA];

    fscanf(file, "%s", tmpLogin);

    while (!feof(file))
    {
        if (!strcmp(tmpLogin, user))
        {
            fscanf(file, "%s", tmpSenha);
            return 1;
        }
        else
        {
            fscanf(file, "%*s");
        }
        fscanf(file, "%s", tmpLogin);
    }
    return 0;
}

char *CriaSenha()
{
    register int i;

    char *senha = (char *)malloc(sizeof *senha * MAX_SENHA);

    for (i = 0; i < MAX_SENHA; i++)
    {
        senha[i] = getch();
        if (senha[i] == '\r')
            break;
        else
            printf("*");
    }
    senha[i] = '\0';

    return senha;
}

int menus()
{
    //===========** MENU **========================================================================

    int m_option, ncase1, ncase2, ncase3, ncase4, i;

    do
    {
        system("cls");
        puts("\n**WIKLATECH**\n\n");
        puts("\n*Menu*\n\n");
        puts("1- Cadastro de Usuarios\n");
        puts("2- Cadastro de funcionarios\n");
        puts("3- Cadastro de clientes\n");
        puts("4- Relatorios\n");
        puts("5- sair\n");

        scanf("%d", &m_option);
        fflush(stdin);

        switch (m_option)
        {
        case 1:
            system("cls");
            puts("\n**WIKLATECH**\n\n");

            ncase1 = cad_user();
            system("pause");
            break;
            //------------------------------------------------------------------------------------------------
        case 2:
            system("cls");
            puts("\n**WIKLATECH**\n\n");

            ncase2 = cad_func();

            system("pause");

            break;
            //------------------------------------------------------------------------------------------------
        case 3:
            system("cls");
            puts("\n**WIKLATECH**\n\n");

            ncase3 = cad_cliente();

            system("pause");
            break;
            //-----------------------------------------------------------------------------------------------
        case 4:
            ncase4 = relatorios();
            break;
            //-----------------------------------------------------------------------------------------------*/
        case 5:
            return 0;

            //-----------------------------------------------------------------------------------------------
        default:
            printf("Escolha 1, 2, 3, 4 ou 5...\n");
            system("pause");
            break;
        }

    } while (1);

    return 0;

} //=====**End menu**==================================================================================


int main(int argc, char *argv[]) {
	
    setlocale(LC_ALL, "Portuguese");
    FILE *fpIN;

    int option = 0, ncase1 = 0, ncase3 = 0, nmenus, npri=0;
    char primeiro[100];
    char *user = (char *)malloc(sizeof *user * MAX_LOGIN);
    char *senha, *confirmaSenha;

    do
    {   npri=0;
        system("cls");
        puts("\n**WIKLATECH**\n\n");
        fpIN = fopen("usuarios.txt", "a+");
        if (fgets(primeiro, 100, fpIN) == NULL)
        {
            fclose(fpIN);
            printf("\n1- Login\n2- Sair\n3- Primeiro Cadastro \n");
            npri=1;
        }
        else
        {   
		    npri=0;
            ncase3 = 2;
            fclose(fpIN);
            printf("1- Login\n2- Sair\n");
        }

        scanf("%d", &option);
        fflush(stdin);

        switch (option)
        {
        case 1:

            printf("Usuario: ");
            gets(user);
            fflush(stdin);
            printf("Senha: ");
            senha = CriaSenha();

            fpIN = fopen("usuarios.txt", "a+");

            ncase1 = checklogin(fpIN, user, senha);
            printf("\n\nUsuario %sconfirmado.\n", ncase1 ? "" : "nao ");
            system("pause");
            fclose(fpIN);
            free(senha);
            if (ncase1 == 1)
                nmenus = menus();

            break;

        case 2:
            return 0;

        case 3:
        	
        	if(npri == 1)
			{
			
	            if (ncase3 < 2)
	            {
	                do
	                {
	                    if (ncase3 == 1)
	                        printf("Usu�rio j� existe digite novamente: ");
	                    else
	                        printf("Usu�rio: ");
	
	                    gets(user);
	                    fflush(stdin);
	                    fpIN = fopen("usuarios.txt", "a+");
	                    ncase3 = checkuser(fpIN, user); // se retorna 1 o login ja existe
	                    fclose(fpIN);
	                } while (ncase3 == 1);
	                do
	                {
	                    printf("Senha de at� 8 digitos: ");
	                    senha = CriaSenha();
	                    printf("\nConfirmac�o de senha: ");
	                    confirmaSenha = CriaSenha();
	                    printf("\n");
	
	                    if (!strcmp(senha, confirmaSenha))
	                        break;
	                    else
	                        printf("As senhas n�o s�o iguais. Tente novamente.\n");
	                } while (1);
	
	                fpIN = fopen("usuarios.txt", "a+");
	                fprintf(fpIN, "%s %s \n", user, senha);
	                fclose(fpIN);
	                system("cls");
	                free(senha);
	                free(confirmaSenha);
	                break;
	            }
	            else
	            {
	                printf("Digite 1 ou 2 ...\n");
	                	getchar();
	                break;
	            }
	        }
			else
			{
				printf("Digite 1 ou 2 ...\n");
				getchar();
	            break;
			}
	        
        default:
        	
		   printf("\nOp��o invalida digite novamente...\n");	
		   getchar();			
            
            break;
        }

    } while (1);

    return (0);	
}
